-- Include your drop table DDL statements in this file.
-- Make sure to terminate each statement with a semicolon (;)

-- LEAVE this statement on. It is required to connect to your database.
CONNECT TO COMP421;

-- Remember to put the drop table ddls for the tables with foreign key references
--    BEFORE the ddls to drop the parent tables (reverse of the creation order).

-- This is only an example of how you add drop table ddls to this file.
--   You may remove it.
DROP TABLE Receives;
DROP TABLE Sends;
DROP TABLE Port_Call;
DROP TABLE Route;
DROP TABLE Voyage;
DROP TABLE Dangerous_Cargo;
DROP TABLE Standard_Cargo;
DROP TABLE Cargos;
DROP TABLE Point_of_Contacts;
DROP TABLE Vessels;
DROP TABLE Safety_Procedure;
DROP TABLE Container;
DROP TABLE Ports;
DROP TABLE Shipping_Party;
DROP TABLE Carrier_Companies;
