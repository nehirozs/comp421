-- Include your INSERT SQL statements in this file.
-- Make sure to terminate each statement with a semicolon (;)

-- LEAVE this statement on. It is required to connect to your database.
CONNECT TO COMP421;

-- Remember to put the INSERT statements for the tables with foreign key references
--    ONLY AFTER the insert for the parent tables!

-- This is only an example of how you add INSERT statements to this file.
--   You may remove it.


INSERT INTO Carrier_Companies VALUES (1, 'OceanBridge Logistics');
INSERT INTO Carrier_Companies VALUES (2, 'BlueWave Marine');
INSERT INTO Carrier_Companies VALUES (3, 'NorthStar Cargo');
INSERT INTO Carrier_Companies VALUES (4, 'Atlas Shipping');
INSERT INTO Carrier_Companies VALUES (5, 'Horizon Freight');

INSERT INTO Shipping_Party VALUES (1, 'Nehir Imports');
INSERT INTO Shipping_Party VALUES (2, 'Aerin Retail');
INSERT INTO Shipping_Party VALUES (3, 'Stalbek Traders');
INSERT INTO Shipping_Party VALUES (4, 'NAS Supply');
INSERT INTO Shipping_Party VALUES (5, 'Aerien Chemicals');
INSERT INTO Shipping_Party VALUES (6, 'Nehir Turkish Foods');

INSERT INTO Ports VALUES (1, 'Canada', 'Montreal');
INSERT INTO Ports VALUES (2, 'Canada', 'Halifax');
INSERT INTO Ports VALUES (3, 'USA', 'New York');
INSERT INTO Ports VALUES (4, 'Istanbul', 'Turkiye');
INSERT INTO Ports VALUES (5, 'Germany', 'Hamburg');
INSERT INTO Ports VALUES (6, 'Belgium', 'Antwerp');
INSERT INTO Ports VALUES (7, 'Singapore', 'Singapore');

INSERT INTO Container VALUES (1001, 'Dry');
INSERT INTO Container VALUES (1002, 'Refrigerated');
INSERT INTO Container VALUES (1003, 'Tank');
INSERT INTO Container VALUES (1004, 'Open Top');
INSERT INTO Container VALUES (1005, 'Dry');
INSERT INTO Container VALUES (1006, 'Refrigerated');
INSERT INTO Container VALUES (1007, 'Tank');
INSERT INTO Container VALUES (1008, 'Dry');
INSERT INTO Container VALUES (1009, 'Open Top');
INSERT INTO Container VALUES (1010, 'Tank');

INSERT INTO Safety_Procedure VALUES (1, 'Flammable materials handling');
INSERT INTO Safety_Procedure VALUES (2, 'Toxic substance isolation');
INSERT INTO Safety_Procedure VALUES (3, 'Corrosive material containment');
INSERT INTO Safety_Procedure VALUES (4, 'Explosive cargo protocol');
INSERT INTO Safety_Procedure VALUES (5, 'Hazardous refrigeration procedure');

INSERT INTO Vessels VALUES (1, 'MV Aurora 3000', 5000, 1);
INSERT INTO Vessels VALUES (2, 'MV Sultan Suleiman', 6200, 1);
INSERT INTO Vessels VALUES (3, 'MV Browne', 5400, 2);
INSERT INTO Vessels VALUES (4, 'MV Jusup', 7000, 3);
INSERT INTO Vessels VALUES (5, 'MV Sokuluk', 6500, 4);
INSERT INTO Vessels VALUES (6, 'MV Bishkek', 5800, 5);

INSERT INTO Point_of_Contacts VALUES (1, 'Alice Morgan', 'alice@oceanbridge.com', '5141110001', 1, 1);
INSERT INTO Point_of_Contacts VALUES (2, 'Brian Cole', 'brian@bluewave.com', '5141110002', 2, 2);
INSERT INTO Point_of_Contacts VALUES (3, 'Celine Park', 'celine@northstar.com', '5141110003', 3, 3);
INSERT INTO Point_of_Contacts VALUES (4, 'David Ross', 'david@atlas.com', '5141110004', 4, 4);
INSERT INTO Point_of_Contacts VALUES (5, 'Emma Lewis', 'emma@horizon.com', '5141110005', 5, 5);
INSERT INTO Point_of_Contacts VALUES (6, 'Farid Khan', 'farid@oceanbridge.com', '5141110006', 1, 6);

INSERT INTO Cargos VALUES (1, 'Electronics shipment', 1001);
INSERT INTO Cargos VALUES (2, 'Frozen seafood', 1002);
INSERT INTO Cargos VALUES (3, 'Industrial chemicals', 1003);
INSERT INTO Cargos VALUES (4, 'Construction steel', 1004);
INSERT INTO Cargos VALUES (5, 'Packaged food', 1005);
INSERT INTO Cargos VALUES (6, 'Medical supplies', 1006);
INSERT INTO Cargos VALUES (7, 'Fuel additives', 1007);
INSERT INTO Cargos VALUES (8, 'Textiles', 1008);
INSERT INTO Cargos VALUES (9, 'Heavy machinery parts', 1009);
INSERT INTO Cargos VALUES (10, 'Cleaning solvents', 1010);
INSERT INTO Cargos VALUES (11, 'Silk Textiles', 1008);

INSERT INTO Standard_Cargo VALUES (1, 1200.50, 35.20);
INSERT INTO Standard_Cargo VALUES (2, 900.00, 28.50);
INSERT INTO Standard_Cargo VALUES (4, 3000.00, 55.00);
INSERT INTO Standard_Cargo VALUES (5, 1400.75, 32.10);
INSERT INTO Standard_Cargo VALUES (6, 700.40, 20.00);
INSERT INTO Standard_Cargo VALUES (8, 1100.00, 30.00);
INSERT INTO Standard_Cargo VALUES (9, 2500.00, 48.00);

INSERT INTO Dangerous_Cargo VALUES (3, 2);
INSERT INTO Dangerous_Cargo VALUES (7, 1);
INSERT INTO Dangerous_Cargo VALUES (10, 3);

INSERT INTO Voyage VALUES (1, '2026-03-01', 1);
INSERT INTO Voyage VALUES (2, '2026-03-05', 2);
INSERT INTO Voyage VALUES (3, '2026-03-10', 3);
INSERT INTO Voyage VALUES (4, '2026-03-15', 4);
INSERT INTO Voyage VALUES (5, '2026-03-20', 5);
INSERT INTO Voyage VALUES (6, '2026-03-25', 6);

INSERT INTO Route VALUES (101, 1, 4);
INSERT INTO Route VALUES (102, 2, 5);
INSERT INTO Route VALUES (103, 1, 6);
INSERT INTO Route VALUES (104, 3, 4);
INSERT INTO Route VALUES (105, 2, 7);
INSERT INTO Route VALUES (106, 4, 5);

INSERT INTO Port_Call VALUES (1, 1, '2026-03-02', 101);
INSERT INTO Port_Call VALUES (1, 2, '2026-03-08', 106);

INSERT INTO Port_Call VALUES (2, 1, '2026-03-06', 102);
INSERT INTO Port_Call VALUES (2, 2, '2026-03-12', 106);

INSERT INTO Port_Call VALUES (3, 1, '2026-03-11', 103);
INSERT INTO Port_Call VALUES (3, 2, '2026-03-17', 101);

INSERT INTO Port_Call VALUES (4, 1, '2026-03-16', 104);
INSERT INTO Port_Call VALUES (4, 2, '2026-03-22', 102);

INSERT INTO Port_Call VALUES (5, 1, '2026-03-21', 105);
INSERT INTO Port_Call VALUES (5, 2, '2026-03-28', 104);

INSERT INTO Port_Call VALUES (6, 1, '2026-03-26', 101);
INSERT INTO Port_Call VALUES (6, 2, '2026-04-01', 103);

INSERT INTO Sends VALUES (1, 1, 1);
INSERT INTO Sends VALUES (1, 3, 5);
INSERT INTO Sends VALUES (2, 2, 6);
INSERT INTO Sends VALUES (2, 4, 4);
INSERT INTO Sends VALUES (3, 5, 1);
INSERT INTO Sends VALUES (3, 7, 5);
INSERT INTO Sends VALUES (4, 6, 2);
INSERT INTO Sends VALUES (4, 8, 3);
INSERT INTO Sends VALUES (5, 9, 4);
INSERT INTO Sends VALUES (5, 10, 5);
INSERT INTO Sends VALUES (6, 1, 1);
INSERT INTO Sends VALUES (6, 2, 6);

INSERT INTO Receives VALUES (2, 1, 2, 1);
INSERT INTO Receives VALUES (4, 1, 2, 3);
INSERT INTO Receives VALUES (1, 2, 2, 2);
INSERT INTO Receives VALUES (3, 2, 2, 4);
INSERT INTO Receives VALUES (6, 3, 2, 5);
INSERT INTO Receives VALUES (2, 3, 2, 7);
INSERT INTO Receives VALUES (4, 4, 2, 6);
INSERT INTO Receives VALUES (5, 4, 2, 8);
INSERT INTO Receives VALUES (3, 5, 2, 9);
INSERT INTO Receives VALUES (1, 5, 2, 10);
INSERT INTO Receives VALUES (6, 6, 2, 1);
INSERT INTO Receives VALUES (2, 6, 2, 2);
