-- Include your create table DDL statements in this file.
-- Make sure to terminate each statement with a semicolon (;)

-- LEAVE this statement on. It is required to connect to your database.
CONNECT TO COMP421;

-- Remember to put the create table ddls for the tables with foreign key references
--    ONLY AFTER the parent tables have already been created.

-- This is only an example of how you add create table ddls to this file.
--   You may remove it.

CREATE TABLE Carrier_Companies
(
company_id INTEGER NOT NULL,
company_name VARCHAR(255) NOT NULL,
PRIMARY KEY(company_id)
);

CREATE TABLE Shipping_Party
(
party_id INTEGER NOT NULL,
party_name VARCHAR(255) NOT NULL,
PRIMARY KEY(party_id)
);

CREATE TABLE Ports
(
port_id INTEGER NOT NULL,
country VARCHAR(255) NOT NULL,
city VARCHAR(255) NOT NULL,
PRIMARY KEY (port_id)
);

CREATE TABLE Container
(
container_number INTEGER NOT NULL,
container_type VARCHAR(255),
PRIMARY KEY(container_number)
);

CREATE TABLE Safety_Procedure
(
procedure_id INTEGER NOT NULL,
procedure_description VARCHAR(255),
PRIMARY KEY(procedure_id)
);

CREATE TABLE Vessels
(
vessel_id INTEGER NOT NULL,
vessel_name VARCHAR(255),
capacity INTEGER,
company_id INTEGER,
PRIMARY KEY (vessel_id),
FOREIGN KEY (company_id) REFERENCES Carrier_Companies(company_id)
);

CREATE TABLE Point_of_Contacts
(
person_id INTEGER NOT NULL,
name VARCHAR(255),
email VARCHAR(255),
phone VARCHAR(30),
company_id INTEGER,
party_id INTEGER,
PRIMARY KEY (person_id),
FOREIGN KEY (company_id) REFERENCES Carrier_Companies(company_id),

FOREIGN KEY (party_id) REFERENCES Shipping_Party(party_id)
);


CREATE TABLE Cargos
(
cargo_id INTEGER NOT NULL,
description VARCHAR(255),
container_number INTEGER,
PRIMARY KEY (cargo_id),

FOREIGN KEY (container_number) REFERENCES Container(container_number)
);


CREATE TABLE Standard_Cargo
(
cargo_id INTEGER NOT NULL,
weight DECIMAL(10,2),
volume DECIMAL(10,2),
PRIMARY KEY (cargo_id),

FOREIGN KEY (cargo_id) REFERENCES Cargos(cargo_id)
);


CREATE TABLE Dangerous_Cargo
(
cargo_id INTEGER NOT NULL,
procedure_id INTEGER,

PRIMARY KEY (cargo_id),

FOREIGN KEY (cargo_id) REFERENCES Cargos(cargo_id),
FOREIGN KEY (procedure_id) REFERENCES Safety_Procedure(procedure_id)
);


CREATE TABLE Voyage
(
voyage_id INTEGER NOT NULL,
departure_date DATE,
vessel_id INTEGER,
PRIMARY KEY (voyage_id),

FOREIGN KEY (vessel_id) REFERENCES Vessels(vessel_id)
);


CREATE TABLE Route
(
route_number INTEGER NOT NULL,
origin_port_id INTEGER,
destination_port_id INTEGER,
PRIMARY KEY (route_number),

FOREIGN KEY (origin_port_id) REFERENCES Ports(port_id),
FOREIGN KEY (destination_port_id) REFERENCES Ports(port_id)
);


CREATE TABLE Port_Call
(
voyage_id INTEGER NOT NULL,
sequence_number INTEGER NOT NULL,
arrival_date DATE,
route_number INTEGER,
PRIMARY KEY (voyage_id, sequence_number),

FOREIGN KEY (voyage_id) REFERENCES Voyage(voyage_id),
FOREIGN KEY (route_number) REFERENCES Route(route_number)
);


CREATE TABLE Sends
(
voyage_id INTEGER NOT NULL,
cargo_id INTEGER NOT NULL,
party_id INTEGER NOT NULL,
PRIMARY KEY (voyage_id, cargo_id, party_id),

FOREIGN KEY (voyage_id) REFERENCES Voyage(voyage_id),
FOREIGN KEY (cargo_id) REFERENCES Cargos(cargo_id),
FOREIGN KEY (party_id) REFERENCES Shipping_Party(party_id)
);


CREATE TABLE Receives
(
party_id INTEGER NOT NULL,
voyage_id INTEGER NOT NULL,
sequence_number INTEGER NOT NULL,
cargo_id INTEGER NOT NULL,

PRIMARY KEY (party_id, voyage_id, sequence_number, cargo_id),

FOREIGN KEY (party_id) REFERENCES Shipping_Party(party_id),
FOREIGN KEY (cargo_id) REFERENCES Cargos(cargo_id),
FOREIGN KEY (voyage_id, sequence_number) REFERENCES Port_Call(voyage_id, sequence_number)
);
